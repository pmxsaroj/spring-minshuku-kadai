const stripe = Stripe('pk_test_51PTcUI06Xx7JhF88FgXOD02q6voKZwpgEkql5zBj3LvQ0NAqaGCKsb3UfPvY8ejp2FScwks73JR1EdqZlF9zMQPf00n9eyMNAs');
const paymentButton = document.querySelector('#paymentButton');

paymentButton.addEventListener('click', () => {
	stripe.redirectToCheckout({
		sessionId: sessionId
	})
});